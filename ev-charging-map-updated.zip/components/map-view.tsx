"use client"

import { useState } from "react"
import {
  Plus,
  Minus,
  Navigation,
  Layers,
  Zap,
  CornerUpLeft,
  X,
} from "lucide-react"

interface MapViewProps {
  selectedDestination: string | null
  isNavigating: boolean
  onClose?: () => void
}

const chargingStations = [
  {
    id: 1,
    name: "Tesla Supercharger 桃園站",
    type: "DC 快充",
    price: 12,
    available: 3,
    address: "桃園市中壢區中山路100號",
    top: "35%",
    left: "40%",
  },
  {
    id: 2,
    name: "U-POWER 桃園站",
    type: "DC 超快充",
    price: 14,
    available: 1,
    address: "桃園市桃園區復興路88號",
    top: "48%",
    left: "60%",
  },
  {
    id: 3,
    name: "EVALUE 八德站",
    type: "AC 慢充",
    price: 8,
    available: 5,
    address: "桃園市八德區介壽路50號",
    top: "65%",
    left: "45%",
  },
]

export function MapView({ selectedDestination, isNavigating }: MapViewProps) {
  const [zoomLevel, setZoomLevel] = useState(15)
  const [selectedStation, setSelectedStation] = useState<any>(null)

  return (
    <div className="relative w-full h-full bg-[#e8f4f4] overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(rgba(50,120,120,0.12) 1px, transparent 1px),
            linear-gradient(90deg, rgba(50,120,120,0.12) 1px, transparent 1px)
          `,
          backgroundSize: `${40 * (zoomLevel / 15)}px ${40 * (zoomLevel / 15)}px`,
        }}
      />

      {chargingStations.map((station) => (
        <button
          key={station.id}
          onClick={() => setSelectedStation(station)}
          className="absolute transform -translate-x-1/2 -translate-y-1/2"
          style={{ top: station.top, left: station.left }}
        >
          <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center shadow-xl border-4 border-white">
            <Zap className="w-6 h-6 text-white" />
          </div>
        </button>
      ))}

      {selectedStation && (
        <div className="absolute bottom-6 left-6 w-[320px] bg-white rounded-3xl shadow-2xl p-5 z-50">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold">
                {selectedStation.name}
              </h2>

              <p className="text-sm text-gray-500 mt-1">
                {selectedStation.address}
              </p>
            </div>

            <button
              onClick={() => setSelectedStation(null)}
              className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>充電類型</span>
              <span className="font-semibold">
                {selectedStation.type}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span>價格</span>
              <span className="text-2xl font-bold text-green-600">
                NT${selectedStation.price}
                <span className="text-sm font-normal"> / kWh</span>
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span>可用充電槍</span>
              <span className="font-semibold text-green-600">
                {selectedStation.available} Available
              </span>
            </div>
          </div>

          <button className="w-full mt-5 h-12 rounded-2xl bg-black text-white font-semibold flex items-center justify-center gap-2">
            <Navigation className="w-5 h-5" />
            開始導航
          </button>
        </div>
      )}

      {isNavigating && (
        <div className="absolute top-4 left-4 bg-white rounded-2xl p-4 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-black flex items-center justify-center">
              <CornerUpLeft className="w-6 h-6 text-white" />
            </div>

            <div>
              <p className="text-sm text-gray-500">下一步</p>
              <p className="font-semibold">200 公尺後右轉</p>
            </div>
          </div>
        </div>
      )}

      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2">
        <button
          onClick={() => setZoomLevel((z) => Math.min(z + 1, 20))}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center"
        >
          <Plus className="w-5 h-5" />
        </button>

        <button
          onClick={() => setZoomLevel((z) => Math.max(z - 1, 1))}
          className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center"
        >
          <Minus className="w-5 h-5" />
        </button>

        <button className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center">
          <Layers className="w-5 h-5" />
        </button>
      </div>
    </div>
  )
}
